import assert from 'node:assert/strict';
import {rng,checkAnswer,numeric,polynomial} from './dist/core.js';
import fs from 'node:fs';
let totals=0, failures=[],varCount=0,families=0;
for(const mod of ['nombres','algebre','geometrie','mesures','donnees_algo','proportion_fonctions']){
 if(!fs.existsSync(`./dist/modules/${mod}.js`)){failures.push({mod,error:'Module manquant'});continue;}
 let {generators,counts}=await import(`./dist/modules/${mod}.js`);
 for(const [id,g] of Object.entries(generators)){families++;for(let v=0;v<(counts[id]||3);v++){varCount++;let fingerprints=new Set;for(let seed=1;seed<=200;seed++){
 try{let q=g(rng(seed),v);assert.equal(q.family,id);assert(q.prompt?.length>5);assert(q.fields?.length>0);assert(q.hints?.length>=2);assert(q.solution);assert([3,4,5,6].includes(q.grade));assert(!JSON.stringify(q).match(/NaN|Infinity|undefined/));let answers=q.fields.map(f=>String(f.answer));let result=checkAnswer(q,answers);if(!result.ok)throw Error(`Canonical answer rejected: ${JSON.stringify(answers)} ${JSON.stringify(q.check)} ${result.message}`);fingerprints.add(q.prompt+JSON.stringify(answers)+q.visual);totals++;
 }catch(e){if(failures.filter(f=>f.id===id&&f.variant===v).length<2)failures.push({id,variant:v,seed,error:e.message});}
 }if(fingerprints.size<2)failures.push({id,variant:v,error:'Pas de variation avec les graines'});}}
}
assert.equal(numeric('1/2'),.5);assert.equal(numeric('-2²'),-4);assert.equal(numeric('(-2)²'),4);assert.equal(numeric('25%'),.25);
for(const s of ['1/0','alert(1)','1+x-x','0/0','0^0'])assert.throws(()=>numeric(s));
let eq={fields:[{kind:'expression'}],check:{type:'expression',values:['2x+6'],form:'reduced'}};
assert.equal(checkAnswer(eq,['x+x+6']).ok,false);assert.equal(checkAnswer(eq,['2x+6']).ok,true);assert.equal(checkAnswer(eq,['2h+6']).ok,false);
let fact={fields:[{kind:'expression'}],check:{type:'expression',values:['2x+6'],form:'factorized'}};
assert.equal(checkAnswer(fact,['2(x+3)']).ok,true);assert.equal(checkAnswer(fact,['2x+6+(0)']).ok,false);
assert.equal(checkAnswer({fields:[{kind:'fraction'}],check:{type:'numeric',values:['1/2']}},['2/4']).ok,true);
assert.equal(checkAnswer({fields:[{kind:'fraction'}],check:{type:'numeric',values:['1/2'],form:'irreducible'}},['2/4']).ok,false);
assert.equal(checkAnswer({fields:[{kind:'fraction'}],check:{type:'numeric',values:['1/2'],form:'irreducible'}},['-1/-2']).ok,true);
let set={fields:[{kind:'text'}],check:{type:'set',values:['-2','2']}};assert.equal(checkAnswer(set,['2;-2']).ok,true);assert.equal(checkAnswer(set,['2']).ok,false);
const summary={families,variants:varCount,seedsPerVariant:200,successfulSamples:totals,failures};fs.mkdirSync('qa',{recursive:true});fs.writeFileSync('qa/qa_generators.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));process.exitCode=failures.length?1:0;
