# maths&go — exigences permanentes

Cette application vise le collège et la partie sans calculatrice du brevet. Préserver les identifiants des familles et variantes, les graines reproductibles et le contrat d’événements. Ne pas brancher un serveur de données élèves sans le travail d’intégration demandé ultérieurement.

## Pédagogie et mathématiques
- Chaque nouvelle variante doit avoir des données mathématiquement admissibles, une correction exacte et deux aides progressives. Une réponse exacte ne suffit pas : vérifier les étapes du corrigé.
- Vérifier la rigueur du vocabulaire dans chaque énoncé, aide, cours et correction : distinguer nombre/chiffre, fraction/quotient, angle/mesure, segment/longueur, aire/périmètre, égalité/équation, événement/issue. Une formulation accessible ne doit jamais être fausse ou ambiguë. L’aide 1 donne une lecture visuelle en mots simples ; l’aide 2 et le cours explicitent la règle et la notation rigoureuses, sans ajouter du texte inutile.
- Privilégier la représentation visuelle adaptée au savoir-faire, puis le calcul et l’abstraction. Les parts d’un même tout sont jointives.
- Le cours présente un exemple distinct de la question en cours. L’aide reste contextualisée.
- Utiliser math-format.js pour les énoncés, libellés, options, aides, cours et corrections. Fractions verticales, exposants, racines, moins mathématique et unités correctement espacées.
- Un point et un angle sont distincts : [angle:ABC] ou [angle:B] rend un chapeau. [vector:AB] rend une flèche. Ne jamais afficher ces marqueurs bruts. Les labels accessibles doivent les lire en toutes lettres.
- Conserver les expressions trigonométriques cohérentes : cos(60°), cos([angle:ABC]), fractions et égalités sans coupure interne maladroite. Ne pas transformer les unités km/h ni la syntaxe des formules de tableur en fractions.
- Ne pas confondre le nouveau programme déployé progressivement et le périmètre de la cohorte Brevet 2027.

## Écrans et vérification
- Téléphone prioritaire, avec ordinateur et projection. Garder les champs proportionnés à la question, les commandes accessibles et les graphiques lisibles. Le clavier tactile fait partie de la vérification.
- Avant livraison, capturer et relire les rendus de toutes les formes modifiées : énoncé, figure, saisie, deux aides, cours et correction. La réussite des tests numériques ne remplace pas cette relecture.
- Vérifier les parcours réels sur petit téléphone, téléphone courant, ordinateur, projection 4:3 et 16:9 : bonne/mauvaise réponse, retour, cours, reprise, bilan et minuteur.
- Distinguer explicitement ce qui a été testé dans un navigateur à différentes tailles de ce qui a été testé sur un véritable téléphone.
- Conserver un rapport de couverture et un bilan des contrôles effectivement réalisés. Ne pas annoncer une validation exhaustive de tous les tirages aléatoires.

## Retours enseignant du 20 octobre 2026
- Pas de slogan « À ton rythme », « Un schéma peut tout éclairer », ni de cadence imposée de cinq questions par jour. L’entrée est « Ma séance ». La programmation pédagogique et le nombre de questions restent à rediscuter.
- « Par niveau » remplace « Ma classe » : ce filtre n’est pas une connexion à une classe réelle ni une progression personnalisée.
- « Passer » doit rester disponible sur téléphone, même après plusieurs erreurs. Les commandes de séance doivent rester accessibles quand le clavier mathématique est ouvert.
- Toute lettre variable utilise la vraie police mathématique locale MG Math : x arrondi et distinct de ×, y, a, b, n, etc. Même exigence dans les champs de calcul littéral, le clavier, les choix et les SVG. Les mots, noms de fonctions et unités restent droits.
- Les expressions restent entières sur petit écran : consigne séparée si nécessaire, aucune coupure au milieu d’un produit, d’un polynôme, d’une fraction ou d’une parenthèse. Une chaîne d’égalités peut être disposée par étapes complètes. Vérifier les cas longs à 320 et 390 px, dans les questions ET les aides, cours, corrections et bilans. Ne pas se satisfaire de l’absence de débordement : contrôler aussi la taille des caractères.
